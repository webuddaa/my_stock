"""
@author: xuxiangfeng
@date: 2022/2/16
@file_name: common_config.py
"""

# 项目目录
PATH = "/xiangfeng/my_stock"

# 服务器公网ip
SERVER_IP = "47.94.99.97"

# 服务的监听端口号
SERVER_PORT = 9999


