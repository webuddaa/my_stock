"""
@author: xuxiangfeng
@date: 2021/11/17
@file_name: message_exception.py
"""


class SendMailException(Exception):
    pass


class SendWechatException(Exception):
    pass
