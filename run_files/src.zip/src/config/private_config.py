"""
@author: xuxiangfeng
@date: 2021/11/21
@file_name: private_config.py
"""


class PrivateConfig:
    EMAIL_ID = "buddaa@163.com"

    EMAIL_PASSWORD = "xdyxxf99"

    JQ_USER_NAME = "15011559175"

    JQ_PASSWORD = "Zengrongjun19"

    WEB_HOOK_KEY = "912c3401-1cd2-4a2b-a4d4-fc21e11915c3"
