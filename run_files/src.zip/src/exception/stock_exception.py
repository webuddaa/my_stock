"""
@author: xuxiangfeng
@date: 2021/11/18
@file_name: stock_exception.py
"""


class StockEmptyError(Exception):
    """股票数据为空"""
